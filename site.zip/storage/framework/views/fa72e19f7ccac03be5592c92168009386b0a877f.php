<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> <?php echo e(Session::get('success')); ?>


            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> <?php echo e(Session::get('error')); ?>


            </div>
        <?php endif; ?>
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="card card-box">
                    <div class="card-head">
                        <header>Ajouter une tâches</header>


                    </div>
                    <div class="card-body ">
                        <!---form start---->
                        <form method="post" action="<?php echo e(route('todo.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Tâche</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Entrer tâche" name="todo">
                                <?php if($errors->all()): ?>
                                    <span class="text-danger"><?php echo e($errors->first("todo")); ?></span>
                                <?php endif; ?>
                            </div>
                            <button type="submit" class="btn btn-primary">Ajouter</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="card card-box">
                    <div class="card-head">
                        <header>Liste des tâches</header>
                        <button id="panel-button"
                                class="mdl-button mdl-js-button mdl-button--icon pull-right"
                                data-upgraded=",MaterialButton">
                            <i class="material-icons">more_vert</i>
                        </button>
                        <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
                            data-mdl-for="panel-button">

                            <a href="<?php echo e(url('alltodo/delete/')); ?>" class="mdl-menu__item"><i class="material-icons">delete</i>Supprimer tous
                            </a>

                        </ul>
                    </div>
                    <div class="card-body ">
                        <ul class="to-do-list ui-sortable" id="sortable-todo">
                            <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->completed==0): ?>
                                <li class="clearfix">
                                    <a href="/todo/completed/<?php echo e($item->id); ?>" class="todo-check pull-left">
                                        <i style="font-size: 10px" class="fa fa-square-oe"></i>
                                        <label for="todo-check2"></label>
                                    </a>
                                    <p class="todo-title"><?php echo e($item->title); ?></p>
                                    </p>
                                    <div class="todo-actionlist pull-right clearfix">
                                        <a href="/delete/todo/<?php echo e($item->id); ?>" class="todo-removes"><i class="fa fa-times"></i></a>
                                    </div>
                                </li>
                             <?php elseif($item->completed==1): ?>
                                <li class="clearfix">
                                    <a class="todo-check pull-left">
                                        <input checked type="checkbox" value="None" id="todo-check<?php echo e($item->id); ?>">
                                        <label for="todo-check1"></label>
                                    </a>
                                    <p class="todo-title line-through"><?php echo e($item->title); ?></p>
                                    </p>
                                    <div class="todo-actionlist pull-right clearfix">
                                        <a href="/delete/todo/<?php echo e($item->id); ?>" class="todo-removes"><i class="fa fa-times"></i></a>
                                        <a href="/undo/todo/<?php echo e($item->id); ?>" class="todo-removes"><i class="fa fa-undo"></i></a>
                                    </div>
                                </li>
                             <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                        </ul>
                    </div>
                </div>
            </div>

    </div>
    <script>
        //if checkbox is checked go to url


    </script>
    <!-- end page content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts._indexuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/5euros/admin/resources/views/user-dash/todo.blade.php ENDPATH**/ ?>