<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-head">
                    <header>MEMBRES</header>
                    <div class="tools">
                        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                        <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                        <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                    </div>
                </div>
                <div class="card-body ">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-6">
                            <div class="btn-group">
                                <a href="<?php echo e(url('addmembres')); ?>" id="addRow1" class="btn btn-info">
                                    Ajouter un membre<i class="fa fa-plus"></i>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-6">

                        </div>
                    </div>
                    <table
                        class="table table-striped table-bordered table-hover table-checkable order-column"
                        style="width: 100%" id="example4">
                        <thead>
                        <tr>
                            <th>
                                ID
                            </th>
                            <th> Nom&Prénom </th>
                            <th> Email </th>
                            <th> Sexe </th>
                            <th> Âge </th>
                            <th> Addresse  </th>
                            <th> Téléphone </th>
                            <th> Departement </th>
                            <th> Actions </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $membres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd gradeX">
                                <td>
                                    <?php echo e($item->membre_id); ?>

                                </td>
                                <td> <?php echo e($item->nom); ?> </td>
                                <td>
                                    <a href="mailto:<?php echo e($item->email); ?>"><?php echo e($item->email); ?> </a>
                                </td>
                                <td>
                                    <span class=""> <?php echo e($item->sexe); ?> </span>
                                </td>
                                <td> <?php echo e($item->age); ?>ans </td>
                                <td> <?php echo e($item->addresse); ?> </td>
                                <td> <?php echo e($item->tel); ?> </td>
                                <td> <?php echo e($item->departement); ?> </td>
                                <td class="valigntop">

                                    <a href="<?php echo e(url('voir/'.$item->id)); ?>" class="tblEditBtn">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(url('editmembres/'.$item->id)); ?>" class="tblEditBtn">
                                        <i class="fa fa-pencil"></i>
                                    </a>
                                    <a onclick="return confirm('êtes-vous sur de cette action ?')" href="<?php echo e(url('deletemembres/'.$item->id)); ?>" class="tblDelBtn">
                                        <i class="fa fa-trash-o"></i>
                                    </a>

                                    <a href="/print-pdf/<?php echo e($item->id); ?>">
                                        <i class="fa fa-file-pdf-o"></i> </a>

                                    <!-- make edit, delete, and print pdf icon  in flex  -->


                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- end page content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts._indexuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/5euros/admin/resources/views/user-dash/index.blade.php ENDPATH**/ ?>