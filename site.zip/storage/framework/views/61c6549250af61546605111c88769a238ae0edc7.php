<?php $__env->startComponent('mail::message'); ?>
# Identifiant de connexion

# Salut <?php echo e($name); ?>

<?php echo e($message); ?>




Merci,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /opt/lampp/htdocs/5euros/admin/resources/views/emails/send.blade.php ENDPATH**/ ?>