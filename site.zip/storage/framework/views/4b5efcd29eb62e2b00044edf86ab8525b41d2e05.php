<?php echo e($slot); ?>

<?php /**PATH /opt/lampp/htdocs/5euros/admin/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>