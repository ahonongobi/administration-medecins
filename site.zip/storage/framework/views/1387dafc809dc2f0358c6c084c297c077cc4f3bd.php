<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-head">
                    <header>Mes Contacts</header>
                    <div class="tools">
                        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                        <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                        <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                    </div>
                </div>
                <div class="card-body ">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-6">
                            <div class="btn-group">
                                <a href="<?php echo e(url('addmembres')); ?>" id="addRow1" class="btn btn-info">
                                    Ajouter un membre<i class="fa fa-plus"></i>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-6">

                        </div>
                    </div>
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('success')); ?>

                        </div>
                    <?php endif; ?>
                    <table
                        class="table table-striped table-bordered table-hover table-checkable order-column"
                        style="width: 100%" id="example4">
                        <thead>
                        <tr>

                             <th> ID </th>
                            <th> Email </th>
                            <th> Téléphone </th>
                            <th> Statut </th>
                            <th> Établissement  </th>
                            <th> Nom et Prénoms </th>
                            <th>Date de création</th>

                            <th> Actions </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd gradeX">

                                <td>
                                    <?php echo e($item->id); ?>

                                </td>
                                <td>
                                    <a href="mailto:<?php echo e($item->email); ?>"><?php echo e($item->email); ?> </a>
                                </td>
                                <td>
                                    <span class=""> <?php echo e($item->tel); ?> </span>
                                </td>
                                <td> <?php echo e($item->statut); ?>ans </td>
                                <td> <?php echo e($item->etablissement); ?> </td>
                                <td> <?php echo e($item->name); ?> </td>
                                <td>
                                    <!--convert to thuis format ;-->
                                    <?php echo e(date('d-m-Y', strtotime($item->created_at))); ?>



                                </td>
                                <td class="valigntop">

                                    <a onclick="return confirm('êtes-vous sur de cette action ?')" href="<?php echo e(url('deletecontact/'.$item->id)); ?>" class="tblDelBtn">
                                        <i class="fa fa-trash-o"></i>
                                    </a>



                                    <!-- make edit, delete, and print pdf icon  in flex  -->


                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- end page content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts._indexuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/5euros/admin/resources/views/user-dash/mycontacts.blade.php ENDPATH**/ ?>