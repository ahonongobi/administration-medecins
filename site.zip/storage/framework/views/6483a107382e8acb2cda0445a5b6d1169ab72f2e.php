<?php $__env->startSection('content'); ?>

    <div class="row">
       <?php echo $__env->make('user-dash.pdf-2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- end page content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts._indexuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/5euros/admin/resources/views/user-dash/voir.blade.php ENDPATH**/ ?>