<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> <?php echo e(Session::get('success')); ?>


            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> <?php echo e(Session::get('error')); ?>


            </div>
        <?php endif; ?>
        <div class="col-md-12 col-sm-12">
            <div class="card card-box">
                <div class="card-head">
                    <header>DETAILS DU PATIENT</header>
                    <!-- alert success message if session has success -->

                    <button id="panel-button1"
                            class="mdl-button mdl-js-button mdl-button--icon pull-right"
                            data-upgraded=",MaterialButton">
                        <i class="material-icons">more_vert</i>
                    </button>
                    <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect"
                        data-mdl-for="panel-button1">
                        <li class="mdl-menu__item"><i class="material-icons">assistant_photo</i>Action
                        </li>
                        <li class="mdl-menu__item"><i class="material-icons">print</i>Another action
                        </li>
                        <li class="mdl-menu__item"><i class="material-icons">favorite</i>Something else
                            here</li>
                    </ul>
                </div>
                <div class="card-body" id="bar-parent1">
                    <form action="<?php echo e(url('editmembres/'.$membre->id)); ?>" method="post" id="form_sample_1" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                        <div class="form-body">
                            <div class="form-group row">
                                <label class="control-label col-md-3">Nom et prénom:
                                    <span class="required"> * </span>
                                </label>
                                <div class="col-md-4">
                                    <input type="text" value="<?php echo e($membre->nom); ?>" name="name" data-required="1"
                                           class="form-control" />
                                    <?php if($errors->has('name')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    <?php endif; ?>
                                </div>


                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Date de naissance:
                                    <span class="required"> * </span>
                                </label>
                                <div class="col-md-4">
                                    <div class="input-group">

                                        <input type="text" value="<?php echo e($membre->birthdate); ?>" class="form-control" name="birthdate"
                                               placeholder="" />
                                        <?php if($errors->has('birthdate')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('birthdate')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Sexe:
                                    <span class="required"> * </span>
                                </label>
                                <div class="col-md-4">
                                    <input name="sexe" value="<?php echo e($membre->sexe); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('sexe')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('sexe')); ?></span>
                                    <?php endif; ?>

                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Age:
                                    <span class="required"> * </span>
                                </label>
                                <div class="col-md-4">
                                    <input name="age" value="<?php echo e($membre->age); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('age')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('age')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Adresse:
                                    <span class="required"> * </span>
                                </label>
                                <div class="col-md-4">
                                    <input name="addresse" value="<?php echo e($membre->addresse); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('addresse')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('addresse')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Department:<span class="required"> * </span></label>
                                <div class="col-md-4">
                                    <input name="departement" value="<?php echo e($membre->departement); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('departement')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('departement')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Email:<span class="required"> * </span></label>
                                <div class="col-md-4">
                                    <input name="email"  value="<?php echo e($membre->email); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('email')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="control-label col-md-3">Téléphone 1:<span class="required"> * </span></label>
                                <div class="col-md-4">
                                    <input name="tel"  value="<?php echo e($membre->tel); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('tel')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('tel')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Téléphone 2:<span class="required"> * </span></label>
                                <div class="col-md-4">
                                    <input name="tel2"  value="<?php echo e($membre->tel2); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('tel2')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('tel2')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Carte assurance : oui - non:<span class="required"> * </span></label>
                                <div class="col-md-4">
                                    <input name="carte"  value="<?php echo e($membre->carte); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('carte')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('carte')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <hr />
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Etablissement :<span class="required"> * </span></label>
                                <div class="col-md-4">
                                    <input name="etablissement"  value="<?php echo e($membre->etablissement); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('etablissement')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('etablissement')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Service :<span class="required"> * </span></label>
                                <div class="col-md-4">
                                    <input name="service"  value="<?php echo e($membre->service); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('service')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('service')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Nom du responsible :<span class="required"> * </span></label>
                                <div class="col-md-4">
                                    <input name="nom_responsable"  value="<?php echo e($membre->nom_responsable); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('tel2')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('tel2')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Valable : oui - non<span class="required"> * </span></label>
                                <div class="col-md-4">
                                    <input name="valable"  value="<?php echo e($membre->valable); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('valable')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('valable')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Arret : oui - non:<span class="required"> * </span></label>
                                <div class="col-md-4">
                                    <input name="arret"  value="<?php echo e($membre->arret); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('arret')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('arret')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Disponibilité oui- non:<span class="required"> * </span></label>
                                <div class="col-md-4">
                                    <input name="disponible"  value="<?php echo e($membre->disponible); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('disponible')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('disponible')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Équipement atribué:<span class="required"> * </span></label>
                                <div class="col-md-4">
                                    <input name="equipement"  value="<?php echo e($membre->equipement); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('equipement')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('equipement')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Effet secondaire :
                                    <span class="required"> * </span></label>
                                <div class="col-md-4">
                                    <input name="effet"  value="<?php echo e($membre->effet); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('effet')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('effet')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Mise a jour le :<span class="required"> * </span></label>
                                <div class="col-md-4">
                                    <input name="date_update"  value="<?php echo e($membre->date_update); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('date_update')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('date_update')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-md-3">Prochaine visite  :<span class="required"> * </span></label>
                                <div class="col-md-4">
                                    <input name="visite"  value="<?php echo e($membre->visite); ?>" type="text" class="form-control" />
                                    <?php if($errors->has('visite')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('visite')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                        </div>

                        <div class="form-group">
                            <div class="offset-md-3 col-md-9">
                                <button type="submit" class="btn btn-info m-r-20">Valider</button>
                                <a href="/user" class="btn btn-default">Annuler</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- end page content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts._indexuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/5euros/admin/resources/views/user-dash/editmembres.blade.php ENDPATH**/ ?>