<?php $__env->startSection('content'); ?>
    <!-- alert success message if session has success -->
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> <?php echo e(Session::get('success')); ?>


        </div>
    <?php endif; ?>

    <div class="col-md-6 col-sm-6 col-xs-6 mb-3">
        <div class="btn-group">
            <form class="d-flex justify-content-center" method="post" action="<?php echo e(url('addprogrammes')); ?>">
                <?php echo csrf_field(); ?>
                <input required type="text" name="programmes" placeholder="nom du programme..." class="form-control">
                <button type="submit" id="addRow"
                        class="btn btn-info">
                    Ajouter
                </button>
            </form>
        </div>
    </div>
    <div class="table-responsive">
        <table
            class="table table-striped table-bordered table-hover table-checkable order-column"
            id="example4">
            <thead>
            <tr>
                <th>
                    ID
                </th>
                <th>Nom du programmes</th>

                <th>Actions </th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $programmes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="odd gradeX">
                    <td>
                        <?php echo e($item->id); ?>

                    </td>
                    <td> <?php echo e($item->title); ?> </td>
                    <td class="center">
                        <div class="btn-group">
                            <button
                                class="btn btn-xs btn-warning btn-circle dropdown-toggle center no-margin"
                                type="button" data-bs-toggle="dropdown"
                                aria-expanded="false"> Actions
                                <i class="fa fa-angle-down"></i>
                            </button>
                            <ul class="dropdown-menu pull-left" role="menu">
                                <li>
                                    <a href="/deleteprogrammes/<?php echo e($item->id); ?>"><i class="fa fa-trash-o"></i>
                                        Supprimer
                                    </a>
                                </li>


                            </ul>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
    </div>
    </div>
    </div>
    </div>


    </div>
    </div>
    <!-- end page content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts._index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/5euros/admin/resources/views/admin-dash/programmes.blade.php ENDPATH**/ ?>