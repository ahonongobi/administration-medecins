@extends('_layouts._indexuser')
@section('content')

    <div class="row">
       @include('user-dash.pdf-2')
    </div>

    <!-- end page content -->
@endsection
